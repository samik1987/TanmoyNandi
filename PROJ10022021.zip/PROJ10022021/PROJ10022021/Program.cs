﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PROJ10022021.Extention;

namespace PROJ10022021
{
    class Program
    {
        static void Main(string[] args)
        {
           
            using(ClassA objA = new ClassA())
            {
                objA.Show();
            }

            ClassA objB = new ClassA();
            ClassX.Display("xxx");

            string name = "rahim";
            Console.WriteLine("From normal classA :" + name.getLength());

            DataStore<string> storeString = new DataStore<string>();
            storeString.Data = "samik";
            storeString.GetData<int>("Test", 6);

            DataStore<int> storeInt = new DataStore<int>();
            storeInt.Data = 4;
            storeInt.GetData<string>(6, "test");

            Console.ReadLine();

        }

        
    }

    public class ClassA : IDisposable
    {
        public  void Show()
        {
            string name = "rahim";
            Console.WriteLine("From normal classA" + name.ToCapital());
        }


        public void Dispose()
        {
            
        }
    }

    public static class ClassX
    {
        public static void Display(string name)
        {
            Console.WriteLine("From normal ClassX");
        }      

    }

    // Generic Class 
    public class DataStore<T>
    {
        public T Data { get; set; }

        public string GetData<Y>(T input1,Y input2)
        {
            return input1.ToString();
        }
    }



}
