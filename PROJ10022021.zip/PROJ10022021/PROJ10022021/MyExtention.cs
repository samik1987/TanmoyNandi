﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJ10022021.Extention
{
    public static class MyExtention
    {
        public static string ToCapital(this string text)
        {
            return text.ToUpper();

        }

        public static int getLength(this string text)
        {
            return text.Length;

        }
    }
}
