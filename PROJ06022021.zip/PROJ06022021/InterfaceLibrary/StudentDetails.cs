﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceLibrary
{
    public class StudentDetails : IStudentDetails
    {
        public void Showname(String text)
        {
            Console.WriteLine("print from Showname of StudentDetails");
        }


        public void View()
        {
            throw new NotImplementedException();
        }
    }

}
