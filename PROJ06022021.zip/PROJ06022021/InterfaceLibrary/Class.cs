﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceLibrary
{
    public class Class : IClass
    {     

        public void GetClassNumber()
        {
            Console.WriteLine("print from Claass implementation");
        }


        public void View()
        {
            throw new NotImplementedException();
        }
    }
}
