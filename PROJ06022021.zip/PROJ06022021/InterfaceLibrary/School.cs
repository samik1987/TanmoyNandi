﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceLibrary
{
    public class School : IClass, IStudentDetails
    {
        public School()
        {
            Console.WriteLine("Constructor without param from School :");
        }
        public School(string text="byDefault")
        {
            if(text.Length<=4)
               Console.WriteLine("Constructor from School with small word:" + text);
            else
                Console.WriteLine("Constructor from School with long word:" + text);

        }

        public void Showname(String text)
        {
            Console.WriteLine("Showname from School");
        }

        public void GetClassNumber()
        {
            Console.WriteLine("GetClassNumber from School");
        }

        void IClass.View()
        {
            Console.WriteLine("View from IClass");
        }

        void IStudentDetails.View()
        {
            Console.WriteLine("View from IStudentDetails");
        }
        //public void GetSchoolDetails()
        //{
        //    Showname();
        //    GetClassNumber();
        //}
    }
}
