﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractLibrary
{
    public abstract class AbstractClassA
    {
        public AbstractClassA()
        {

            Console.WriteLine("print from Constructor - abstract class A");
        }
        // Normal Method
        public void Add()
        {
            Console.WriteLine("print from Add - abstract class A");
        }

        // Abstract Mrthod
        public abstract void Sub(int Salary);
       
    }

}
