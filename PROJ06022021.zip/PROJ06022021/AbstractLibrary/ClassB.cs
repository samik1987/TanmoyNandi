﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractLibrary
{
    public class ClassB : AbstractClassA
    {

        public override void Sub(int Salary)
        {
            Console.WriteLine("print from Sub - abstract class B");
        }
    }

    public class ClassC : ClassB
    {

    }
}
