﻿using AbstractLibrary;
using InterfaceLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace PROJ06022021
{
    class Program
    {
        static void Main(string[] args)
        {
            AbstractClassA objA = new ClassC();
            objA.Add();
            objA.Sub(20000);


            IStudentDetails objStu = new School("Me");
            objStu.Showname("test");
            objStu.View();


            IClass objCls = new School();
            objCls.GetClassNumber();
            objCls.View();

            check(56565);

           

            Console.Read();

        }


        public static void check(int phone, String name = "Default")
        {

        }
    }
}
