﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test;


namespace PROJ04022021
{
    class Program : ClassA
    {
        static void Main(string[] args)
        {
            //ClassA objA = new ClassA();
            //objA.name = "Samik";
            //Console.WriteLine("Variable of Class A :" + objA.name);
            
            //objA.age = 2; // set property
            //Console.WriteLine("Property of Class A :" + objA.age); // get property

            ClassParent objX = new ClassX();
            objX.Add(2, 3);

            ClassParent objP = new ClassParent();
            objP.Add(2, 3);

            // * Copncept of Over Loading * //
            //objX.Add(4, 5, 6);
            //objX.Add(5, "Test");
            //objX.Add("Check", 5);
            Console.Read();
        }

        //public void work()
        //{
        //    show();
        //}
    }
}
