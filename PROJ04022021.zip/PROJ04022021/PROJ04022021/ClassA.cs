﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    class ClassA
    {
        // member variable
        public String name = "Ram";

        // member Method
        protected  void show()
        {
            //age = 34;
            Console.WriteLine("Printing from ClassA - Show");
        }
        
        public void display()
        {
            show();
        }

        // Class Property 
        //public string age { get; set; }
        private int _age;

        public int age
        {

            get
            {

                return _age * 2;

            }

            set
            {

                if (value >= 20)

                   _age = value;

            }

        }

    }

    class ClassB : ClassA
    {

        public void Something()
        {
            show();
        }


    }
}
