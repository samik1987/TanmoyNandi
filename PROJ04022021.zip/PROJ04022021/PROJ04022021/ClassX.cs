﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROJ04022021
{
    public class ClassParent
    {
        public virtual void Add(int x, int y)
        {
            Console.WriteLine("Result of Addition ClassParent =" + (x + y));
        }
    }
    public class ClassX : ClassParent
    {
        public override void Add(int x, int y )
        {
            Console.WriteLine("Result of Addition ClassX =" + (x + y));
        }
       
        // * Copncept of Over Loading * //
        //public void Add(int x, int y , int z)
        //{
        //    Console.WriteLine("Result of Addition 2 =" + (x + y+ z));
        //}

        //public void Add(int x, string z)
        //{
        //    Console.WriteLine("Result of Addition 3 =" + (x + z));
        //}

        //public void Add(string z,int x)
        //{
        //    Console.WriteLine("Result of Addition 4 =" + (z + x));
        //}
    }
}
